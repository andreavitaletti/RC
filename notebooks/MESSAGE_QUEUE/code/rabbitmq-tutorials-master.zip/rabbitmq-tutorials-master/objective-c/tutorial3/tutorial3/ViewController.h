//
//  ViewController.h
//  tutorial3
//
//  Created by Pivotal on 25/04/2016.
//  Copyright © 2016 RabbitMQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

